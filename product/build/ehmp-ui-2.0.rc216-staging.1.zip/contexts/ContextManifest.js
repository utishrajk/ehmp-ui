define(function() {
    'use strict';

    return {
        contexts: [{
            id: 'workspace'
        }]
    };
});