define([
], function() {
    'use strict';

var Config = {
    // Switch ON/OFF debug info
        debug: false
    };
  return Config;
});
