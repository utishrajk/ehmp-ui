Add the following comment at the top of every SASS file:

/*!
*******WARNING*******
Do not edit CSS files directly
All CSS changes should be made in SASS (.scss) files only!!
*******  END  *******

For more information/documentation on SASS please visit their website at: http://sass-lang.com/
*/