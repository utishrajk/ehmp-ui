define([

], function() {
    'use strict';
    var handlers = {

    };

    return handlers;
});
