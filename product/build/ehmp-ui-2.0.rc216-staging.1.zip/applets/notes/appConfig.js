define([], function() {
	'use strict';

	var Config = {
		PREVIEW_TITLE: 'Preview Progress Note',
        PREVIEW_TITLE_UNSIGNED: 'Preview Note - TIU Format',
//		PREVIEW_ANIM_SPEED: 0.42 // seconds

        AUTOSAVE_INTERVAL: 30000
	};

	return Config;
});