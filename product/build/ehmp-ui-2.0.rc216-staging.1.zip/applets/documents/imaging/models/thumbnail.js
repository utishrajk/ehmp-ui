define(['backbone',
    'underscore'
], function(Backbone, _) {
    "use strict";

    var Thumbnail = Backbone.Model.extend({
    });
    return Thumbnail;

});